The zip file contains the
followings:

- \sql\linkcenter.sql (sql scripts for creating 2 tables in mysql database)
- \meshcms\admin\modules\link_center
    - \css\linkcenter.css (stylesheet for the module)
    - \images (background images for the boxes (header, background and bottom images, a semi-transparent background for the dialog, header 
    background for editor parts and an icon.gif for the categories without given category image (this should be replaced in the future)
- \src\java\org\meshcms\contrib\modules\linkcenter with locales (these locales are packed in the WEB-INF\lib\linkcenter.jar anyway for testing)
- \WEB-INF\lib (the above mentioned jar file with the locales)
- \WEB-INF\classes\db.properties (a Properties file with the JNDI name
definition for the DataSource)
