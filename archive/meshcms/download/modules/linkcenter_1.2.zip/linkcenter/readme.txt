Readme.txt for eCards MeshCMS module
(C) Copyright Gy�rgy Vilmos Papp 2008

Prerequisites

- MySQL 5.x database connection and JDBC drivers for the TOMCAT installation
- MeshCMS 3.2+ (maybe earlier version is OK, but not tested)

INSTALL
- copy WEB-INF\lib\*.jar file into your app's WEB-INF\lib directory
- set the jndi parameter in WEB-INF\classes\db.properties
- execute the sql\linkcenter.sql script
- copy meshcms\admin\modules directory's content into your app's meshcms\admin\modules directory


[link center module]
-------------------------------------------------------------------------------------------------
MODULE parameters 
- NO PARAMETERS REQUIRED

Advanced parameters for this module:
- NO ADVANCED PARAMETERS REQUIRED

[link suggest module]
-------------------------------------------------------------------------------------------------
MODULE parameters 
- Parameter: path to a directory used to hold the temporary files of urls. If not provided, a default directory will be used.

Advanced parameters for this module:
- form_css: the ccs class of the div that contains the entire form. The default value is mailform;
- field_css: the css class of the individual form fields. The default value is formfields;
- notify: an optional e-mail address to receive comment notifications;
- max_age: maximum number of days after which comments are not shown (default no maximum);
- moderated: hides comments until approved by an authenticated user (default false);
- math: asks users to calculate the sum of two numbers (default false);
- captcha: shows a CAPTCHA image (default true).

