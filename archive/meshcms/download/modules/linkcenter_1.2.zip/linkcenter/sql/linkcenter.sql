/*Table structure for table `url` */

DROP TABLE IF EXISTS `url`;

CREATE TABLE `url` (
  `Id` bigint(20) unsigned NOT NULL auto_increment,
  `GroupId` bigint(20) unsigned NOT NULL,
  `Name` varchar(45) NOT NULL,
  `URL` varchar(255) NOT NULL,
  PRIMARY KEY  (`Id`),
  KEY `FK_url_1` (`GroupId`),
  CONSTRAINT `FK_url_1` FOREIGN KEY (`GroupId`) REFERENCES `urlgroup` (`Id`) ON DELETE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

/*Table structure for table `urlgroup` */

DROP TABLE IF EXISTS `urlgroup`;

CREATE TABLE `urlgroup` (
  `Id` bigint(20) unsigned NOT NULL auto_increment,
  `Name` varchar(45) NOT NULL,
  `ImageUrl` varchar(255) NOT NULL,
  `ColumnIdx` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
