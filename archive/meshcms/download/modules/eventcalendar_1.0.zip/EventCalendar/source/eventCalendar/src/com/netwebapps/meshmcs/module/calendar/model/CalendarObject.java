/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package com.netwebapps.meshmcs.module.calendar.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.Enumeration;
import java.util.Vector;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class CalendarObject.
 * 
 * @version $Revision$ $Date$
 */
public class CalendarObject implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _calendarMonthObject
     */
    private com.netwebapps.meshmcs.module.calendar.model.CalendarMonthObject _calendarMonthObject;

    /**
     * Field _calendarEventObjectList
     */
    private java.util.Vector _calendarEventObjectList;


      //----------------/
     //- Constructors -/
    //----------------/

    public CalendarObject() {
        super();
        _calendarEventObjectList = new Vector();
    } //-- com.netwebapps.meshmcs.module.calendar.model.CalendarObject()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addCalendarEventObject
     * 
     * @param vCalendarEventObject
     */
    public void addCalendarEventObject(com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject vCalendarEventObject)
        throws java.lang.IndexOutOfBoundsException
    {
        _calendarEventObjectList.addElement(vCalendarEventObject);
    } //-- void addCalendarEventObject(com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject) 

    /**
     * Method addCalendarEventObject
     * 
     * @param index
     * @param vCalendarEventObject
     */
    public void addCalendarEventObject(int index, com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject vCalendarEventObject)
        throws java.lang.IndexOutOfBoundsException
    {
        _calendarEventObjectList.insertElementAt(vCalendarEventObject, index);
    } //-- void addCalendarEventObject(int, com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject) 

    /**
     * Method enumerateCalendarEventObject
     */
    public java.util.Enumeration enumerateCalendarEventObject()
    {
        return _calendarEventObjectList.elements();
    } //-- java.util.Enumeration enumerateCalendarEventObject() 

    /**
     * Method getCalendarEventObject
     * 
     * @param index
     */
    public com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject getCalendarEventObject(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _calendarEventObjectList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject) _calendarEventObjectList.elementAt(index);
    } //-- com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject getCalendarEventObject(int) 

    /**
     * Method getCalendarEventObject
     */
    public com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject[] getCalendarEventObject()
    {
        int size = _calendarEventObjectList.size();
        com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject[] mArray = new com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject) _calendarEventObjectList.elementAt(index);
        }
        return mArray;
    } //-- com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject[] getCalendarEventObject() 

    /**
     * Method getCalendarEventObjectCount
     */
    public int getCalendarEventObjectCount()
    {
        return _calendarEventObjectList.size();
    } //-- int getCalendarEventObjectCount() 

    /**
     * Method getCalendarMonthObjectReturns the value of field
     * 'calendarMonthObject'.
     * 
     * @return the value of field 'calendarMonthObject'.
     */
    public com.netwebapps.meshmcs.module.calendar.model.CalendarMonthObject getCalendarMonthObject()
    {
        return this._calendarMonthObject;
    } //-- com.netwebapps.meshmcs.module.calendar.model.CalendarMonthObject getCalendarMonthObject() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeAllCalendarEventObject
     */
    public void removeAllCalendarEventObject()
    {
        _calendarEventObjectList.removeAllElements();
    } //-- void removeAllCalendarEventObject() 

    /**
     * Method removeCalendarEventObject
     * 
     * @param index
     */
    public com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject removeCalendarEventObject(int index)
    {
        java.lang.Object obj = _calendarEventObjectList.elementAt(index);
        _calendarEventObjectList.removeElementAt(index);
        return (com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject) obj;
    } //-- com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject removeCalendarEventObject(int) 

    /**
     * Method setCalendarEventObject
     * 
     * @param index
     * @param vCalendarEventObject
     */
    public void setCalendarEventObject(int index, com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject vCalendarEventObject)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _calendarEventObjectList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _calendarEventObjectList.setElementAt(vCalendarEventObject, index);
    } //-- void setCalendarEventObject(int, com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject) 

    /**
     * Method setCalendarEventObject
     * 
     * @param calendarEventObjectArray
     */
    public void setCalendarEventObject(com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject[] calendarEventObjectArray)
    {
        //-- copy array
        _calendarEventObjectList.removeAllElements();
        for (int i = 0; i < calendarEventObjectArray.length; i++) {
            _calendarEventObjectList.addElement(calendarEventObjectArray[i]);
        }
    } //-- void setCalendarEventObject(com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject) 

    /**
     * Method setCalendarMonthObjectSets the value of field
     * 'calendarMonthObject'.
     * 
     * @param calendarMonthObject the value of field
     * 'calendarMonthObject'.
     */
    public void setCalendarMonthObject(com.netwebapps.meshmcs.module.calendar.model.CalendarMonthObject calendarMonthObject)
    {
        this._calendarMonthObject = calendarMonthObject;
    } //-- void setCalendarMonthObject(com.netwebapps.meshmcs.module.calendar.model.CalendarMonthObject) 

    /**
     * Method unmarshal
     * 
     * @param reader
     */
    public static com.netwebapps.meshmcs.module.calendar.model.CalendarObject unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.netwebapps.meshmcs.module.calendar.model.CalendarObject) Unmarshaller.unmarshal(com.netwebapps.meshmcs.module.calendar.model.CalendarObject.class, reader);
    } //-- com.netwebapps.meshmcs.module.calendar.model.CalendarObject unmarshal(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
