/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package com.netwebapps.meshmcs.module.calendar.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class CalendarEventObject.
 * 
 * @version $Revision$ $Date$
 */
public class CalendarEventObject implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _startDate
     */
    private java.lang.String _startDate;

    /**
     * Field _endDate
     */
    private java.lang.String _endDate;

    /**
     * Field _startTime
     */
    private java.lang.String _startTime;

    /**
     * Field _endTime
     */
    private java.lang.String _endTime;

    /**
     * Field _subject
     */
    private java.lang.String _subject;

    /**
     * Field _allDayEvent
     */
    private java.lang.String _allDayEvent;

    /**
     * Field _private
     */
    private java.lang.String _private;

    /**
     * Field _location
     */
    private java.lang.String _location;

    /**
     * Field _description
     */
    private java.lang.String _description;


      //----------------/
     //- Constructors -/
    //----------------/

    public CalendarEventObject() {
        super();
    } //-- com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method getAllDayEventReturns the value of field
     * 'allDayEvent'.
     * 
     * @return the value of field 'allDayEvent'.
     */
    public java.lang.String getAllDayEvent()
    {
        return this._allDayEvent;
    } //-- java.lang.String getAllDayEvent() 

    /**
     * Method getDescriptionReturns the value of field
     * 'description'.
     * 
     * @return the value of field 'description'.
     */
    public java.lang.String getDescription()
    {
        return this._description;
    } //-- java.lang.String getDescription() 

    /**
     * Method getEndDateReturns the value of field 'endDate'.
     * 
     * @return the value of field 'endDate'.
     */
    public java.lang.String getEndDate()
    {
        return this._endDate;
    } //-- java.lang.String getEndDate() 

    /**
     * Method getEndTimeReturns the value of field 'endTime'.
     * 
     * @return the value of field 'endTime'.
     */
    public java.lang.String getEndTime()
    {
        return this._endTime;
    } //-- java.lang.String getEndTime() 

    /**
     * Method getLocationReturns the value of field 'location'.
     * 
     * @return the value of field 'location'.
     */
    public java.lang.String getLocation()
    {
        return this._location;
    } //-- java.lang.String getLocation() 

    /**
     * Method getPrivateReturns the value of field 'private'.
     * 
     * @return the value of field 'private'.
     */
    public java.lang.String getPrivate()
    {
        return this._private;
    } //-- java.lang.String getPrivate() 

    /**
     * Method getStartDateReturns the value of field 'startDate'.
     * 
     * @return the value of field 'startDate'.
     */
    public java.lang.String getStartDate()
    {
        return this._startDate;
    } //-- java.lang.String getStartDate() 

    /**
     * Method getStartTimeReturns the value of field 'startTime'.
     * 
     * @return the value of field 'startTime'.
     */
    public java.lang.String getStartTime()
    {
        return this._startTime;
    } //-- java.lang.String getStartTime() 

    /**
     * Method getSubjectReturns the value of field 'subject'.
     * 
     * @return the value of field 'subject'.
     */
    public java.lang.String getSubject()
    {
        return this._subject;
    } //-- java.lang.String getSubject() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method setAllDayEventSets the value of field 'allDayEvent'.
     * 
     * @param allDayEvent the value of field 'allDayEvent'.
     */
    public void setAllDayEvent(java.lang.String allDayEvent)
    {
        this._allDayEvent = allDayEvent;
    } //-- void setAllDayEvent(java.lang.String) 

    /**
     * Method setDescriptionSets the value of field 'description'.
     * 
     * @param description the value of field 'description'.
     */
    public void setDescription(java.lang.String description)
    {
        this._description = description;
    } //-- void setDescription(java.lang.String) 

    /**
     * Method setEndDateSets the value of field 'endDate'.
     * 
     * @param endDate the value of field 'endDate'.
     */
    public void setEndDate(java.lang.String endDate)
    {
        this._endDate = endDate;
    } //-- void setEndDate(java.lang.String) 

    /**
     * Method setEndTimeSets the value of field 'endTime'.
     * 
     * @param endTime the value of field 'endTime'.
     */
    public void setEndTime(java.lang.String endTime)
    {
        this._endTime = endTime;
    } //-- void setEndTime(java.lang.String) 

    /**
     * Method setLocationSets the value of field 'location'.
     * 
     * @param location the value of field 'location'.
     */
    public void setLocation(java.lang.String location)
    {
        this._location = location;
    } //-- void setLocation(java.lang.String) 

    /**
     * Method setPrivateSets the value of field 'private'.
     * 
     * @param _private
     * @param private the value of field 'private'.
     */
    public void setPrivate(java.lang.String _private)
    {
        this._private = _private;
    } //-- void setPrivate(java.lang.String) 

    /**
     * Method setStartDateSets the value of field 'startDate'.
     * 
     * @param startDate the value of field 'startDate'.
     */
    public void setStartDate(java.lang.String startDate)
    {
        this._startDate = startDate;
    } //-- void setStartDate(java.lang.String) 

    /**
     * Method setStartTimeSets the value of field 'startTime'.
     * 
     * @param startTime the value of field 'startTime'.
     */
    public void setStartTime(java.lang.String startTime)
    {
        this._startTime = startTime;
    } //-- void setStartTime(java.lang.String) 

    /**
     * Method setSubjectSets the value of field 'subject'.
     * 
     * @param subject the value of field 'subject'.
     */
    public void setSubject(java.lang.String subject)
    {
        this._subject = subject;
    } //-- void setSubject(java.lang.String) 

    /**
     * Method unmarshal
     * 
     * @param reader
     */
    public static com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject) Unmarshaller.unmarshal(com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject.class, reader);
    } //-- com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject unmarshal(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
