package com.netwebapps.meshmcs.module.calendar;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;

import com.netwebapps.meshmcs.module.calendar.model.CalendarMonthObject;
import com.netwebapps.meshmcs.module.calendar.model.CalendarObject;
import com.netwebapps.meshmcs.module.calendar.reader.CalendarReader;
import com.netwebapps.meshmcs.module.calendar.reader.CvsCalendarReader;


public class CalendarManager {
	
	private String arguments = null;
	String advancedArguments = null;
	private TransformerFactory transformerFactory =
		TransformerFactory.newInstance();
	private Transformer transformer = null;
	private String calendarHome = null;
	private String renderDate = null;
	
	public CalendarManager(){
	}
	

	public String getArguments() {
		return arguments;
	}

	public void setArguments(String a) {
		this.arguments = a;
	}

	public String getAdvancedArguments() {
		return advancedArguments;
	}

	public void setAdvancedArguments(String a) {
		this.advancedArguments = a;
	}
	
	private Reader getStyleSheet() throws IOException{
		
		if(getAdvancedArguments() != null){
			return new FileReader(getAdvancedArguments());
		}else{
			return new FileReader(getCalendarHome() + "calendar.xsl");
		}
	}

	public String getCalendarHome() {
		return calendarHome;
	}

	public void setCalendarHome(String d) {
		this.calendarHome = d;
	}

	public String getRenderDate() {
		return renderDate;
	}


	public void setRenderDate(String renderDate) {
		this.renderDate = renderDate;
	}
	
	public String transform(){
		
		String htmlString = "";
		try {
			/**
			 * The calendar.xml file caches the latest events and calendar information
			 */
			//load latest calendar xml data
			File xmlCalendarFile = new File(getCalendarHome() + "calendar.xml");
			//hold calendar date for comparison
			long xmlCalendarFileDate = xmlCalendarFile.lastModified();
			//prepare the xmlCalendarFile for reading
			FileReader xmlReader = new FileReader(xmlCalendarFile);
			//Read in xmlCalendarFile and convert it to xml object model
			CalendarObject xmlCalendar = (CalendarObject) 
			Unmarshaller.unmarshal(CalendarObject.class, xmlReader);
			//close the reader
			xmlReader.close();
			
			//prepare the xmlCalendarFile to be upated.
			boolean overwriteXml = false;
			
			if(getArguments() != null){
				/**
				 * If an argument is passed to the page with a URI pointing
				 * to a csv file with calendar information, the xml file
				 * above will be overwritten with the new information.
				 */
				File csvCalendarFile = new File(getArguments());
				//get the csv's lastModifiedDate for comparison
				long csvCalanderFileDate = csvCalendarFile.lastModified();
				//if the csv file is newer than the xml file convert the csv to
				//xml for storage.
				if(xmlCalendarFileDate < csvCalanderFileDate){
					
					//CvsCalendarReader converts a csv file into a calendar object.
					CalendarReader calReader = new CvsCalendarReader();
					FileInputStream fileReader = new FileInputStream(csvCalendarFile);
					InputStreamReader inReader = new InputStreamReader(fileReader);
					xmlCalendar = (CalendarObject) calReader.readCalendar(inReader);
					fileReader.close();
					inReader.close();
					//prepare the xml file to be overwritten.
					overwriteXml = true;
				}
			}else{
				//if no csv exists update the age of the xml file
				xmlCalendarFile.setLastModified(new Date().getTime());
			}
			
			GregorianCalendar cal = new GregorianCalendar();
			cal.setTimeInMillis(new Date().getTime());
			
			/*
			 * The value for renderDate will tell us if the calendar is moving
			 * forward or backword in time.
			 */
			if(renderDate != null){
				cal.clear();
				String[] renderDateString = renderDate.split(",");
				int monthValue = Integer.valueOf(renderDateString[0]).intValue();
				int yearValue = Integer.valueOf(renderDateString[1]).intValue();
				String direction = renderDateString[2];
				cal.set(yearValue, monthValue, 1);
				
				if(direction.equals("+1")){
					cal.add(Calendar.MONTH, +1);
				}else{
					cal.add(Calendar.MONTH, -1);
				}
			}
			
			//calendar must be on the first day for the other calculations to come out right.
			cal.set(Calendar.DATE, 1);
			CalendarMonthObject calendarMonthObject = xmlCalendar.getCalendarMonthObject();
			if(calendarMonthObject == null){
				calendarMonthObject = new CalendarMonthObject();
				xmlCalendar.setCalendarMonthObject(calendarMonthObject);
			}
			//get the number of days in the month
			calendarMonthObject.setMonthDays(String.valueOf(cal.getActualMaximum(Calendar.DAY_OF_MONTH)));
			//get the value for week day that this month start on.
			calendarMonthObject.setStartDay(String.valueOf(cal.get(Calendar.DAY_OF_WEEK)));
			//get the value for month and convert to 1 based.
			calendarMonthObject.setMonthNumber(String.valueOf(cal.get(Calendar.MONTH)));
			//get the year of the month
			calendarMonthObject.setCalendarYear(String.valueOf(cal.get(Calendar.YEAR)));
			String[] months = new String[]{"January","February","March","April","May","June","July","August","September","October","November","December"};
			//get the proper name of the month
			calendarMonthObject.setMonthName(months[cal.get(Calendar.MONTH)]);
			
			if(overwriteXml){
				//write the calendar xml to cache.
				FileWriter xmlFileWriter = new FileWriter(xmlCalendarFile);
				Marshaller xmlMarshaller = new Marshaller(xmlFileWriter);
				xmlMarshaller.marshal(xmlCalendar);
				xmlFileWriter.close();
			}
			
			//convert CalendarObject to string for the transformer
			StringWriter xmlStringWriter = new StringWriter();
			Marshaller marshaller = new Marshaller(xmlStringWriter);
			marshaller.marshal(xmlCalendar);
			
			//transform xml to html using the xsl stylesheet
			//getStyleSheet will return your custom style sheet or the default
			//if one is not specified in advanced arguments.
			transformer =
				transformerFactory.newTransformer(new StreamSource(getStyleSheet()));
			Reader xmlCalendarReader = new StringReader(xmlStringWriter.toString());
			Writer htmlWriter = new StringWriter();
			transformer.transform(
				new StreamSource(xmlCalendarReader),
				new StreamResult(htmlWriter));
			htmlString =  htmlWriter.toString();
			xmlStringWriter.close();
		} catch (MarshalException e) {
			return e.getMessage();
		} catch (FileNotFoundException e) {
			return e.getMessage();
		} catch (ValidationException e) {
			return e.getMessage();
		} catch(Exception e){
			return e.getMessage();
		}
		return htmlString;
	}
}
