package com.netwebapps.meshmcs.module.calendar.reader;

import java.io.Reader;

public interface CalendarReader {
	
	public Object readCalendar(Reader in) throws Exception;

}
