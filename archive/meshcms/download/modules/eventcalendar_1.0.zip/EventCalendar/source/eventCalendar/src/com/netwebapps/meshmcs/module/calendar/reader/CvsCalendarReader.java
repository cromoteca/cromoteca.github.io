package com.netwebapps.meshmcs.module.calendar.reader;

import java.io.Reader;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.csvreader.CsvReader;
import com.netwebapps.meshmcs.module.calendar.model.CalendarEventObject;
import com.netwebapps.meshmcs.module.calendar.model.CalendarObject;

public class CvsCalendarReader implements CalendarReader{

	public Object readCalendar(Reader in) throws Exception {
		
		CalendarObject calendar = new CalendarObject();
		CsvReader reader = new CsvReader(in);
		reader.readHeaders();
		SimpleDateFormat stringToDate = new SimpleDateFormat("mm/dd/yy");
		SimpleDateFormat dateToString = new SimpleDateFormat("m/d/yyyy");
		
		while (reader.readRecord())
		{
			String subject = reader.get("Subject");
			subject = subject.replaceAll("</?\\S+?[\\s\\S+]*?>", " ");
			subject = subject.replaceAll("'", "&#39;");
			subject = subject.replaceAll("\"", "&quot;");
			subject = subject.replaceAll("\n", " ");
			String start_date = dateToString.format((Date)stringToDate.parse(reader.get("Start Date")));
			//System.out.println("start_date:" + start_date);
			String start_time = reader.get("Start Time");
			//System.out.println("start_time:" + start_time);
			String end_date = reader.get("End Date");
			//System.out.println("end_date:" + end_date);
			String end_time = reader.get("End Time");
			//System.out.println("end_time:" + end_time);
			String all_day_event = reader.get("All day event");
			//System.out.println("all_day_event:" + all_day_event);
			String is_private = reader.get("Private");
			//System.out.println("is_private:" + is_private);
			String location = reader.get("Location");
			location = location.replaceAll("</?\\S+?[\\s\\S+]*?>", " ");
			location = location.replaceAll("'", "&#39;");
			location = location.replaceAll("\"", "&quot;");
			location = location.replaceAll("\n", " ");
			//System.out.println("location:" + location);
			String description = reader.get("Description");
			description = description.replaceAll("</?\\S+?[\\s\\S+]*?>", " ");
			description = description.replaceAll("'", "&#39;");
			description = description.replaceAll("\"", "&quot;");
			description = description.replaceAll("\n", " ");
			//System.out.println("description:" + description);
			
			try{
				CalendarEventObject calEvt = new CalendarEventObject();
				calEvt.setSubject(subject);
				calEvt.setStartDate(start_date);
				calEvt.setEndDate(end_date);
				calEvt.setStartTime(start_time);
				calEvt.setEndTime(end_time);
				calEvt.setAllDayEvent(all_day_event);
				calEvt.setPrivate(is_private);
				calEvt.setLocation(location);
				calEvt.setDescription(description);
				calendar.addCalendarEventObject(calEvt);
			}catch(Exception e){
				e.printStackTrace();
			}
		}

		reader.close();
		return calendar;
	}

		
}
