/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package com.netwebapps.meshmcs.module.calendar.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class CalendarMonthObject.
 * 
 * @version $Revision$ $Date$
 */
public class CalendarMonthObject implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _monthName
     */
    private java.lang.String _monthName;

    /**
     * Field _calendarYear
     */
    private java.lang.String _calendarYear;

    /**
     * Field _monthNumber
     */
    private java.lang.String _monthNumber;

    /**
     * Field _monthDays
     */
    private java.lang.String _monthDays;

    /**
     * Field _startDay
     */
    private java.lang.String _startDay;


      //----------------/
     //- Constructors -/
    //----------------/

    public CalendarMonthObject() {
        super();
    } //-- com.netwebapps.meshmcs.module.calendar.model.CalendarMonthObject()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method getCalendarYearReturns the value of field
     * 'calendarYear'.
     * 
     * @return the value of field 'calendarYear'.
     */
    public java.lang.String getCalendarYear()
    {
        return this._calendarYear;
    } //-- java.lang.String getCalendarYear() 

    /**
     * Method getMonthDaysReturns the value of field 'monthDays'.
     * 
     * @return the value of field 'monthDays'.
     */
    public java.lang.String getMonthDays()
    {
        return this._monthDays;
    } //-- java.lang.String getMonthDays() 

    /**
     * Method getMonthNameReturns the value of field 'monthName'.
     * 
     * @return the value of field 'monthName'.
     */
    public java.lang.String getMonthName()
    {
        return this._monthName;
    } //-- java.lang.String getMonthName() 

    /**
     * Method getMonthNumberReturns the value of field
     * 'monthNumber'.
     * 
     * @return the value of field 'monthNumber'.
     */
    public java.lang.String getMonthNumber()
    {
        return this._monthNumber;
    } //-- java.lang.String getMonthNumber() 

    /**
     * Method getStartDayReturns the value of field 'startDay'.
     * 
     * @return the value of field 'startDay'.
     */
    public java.lang.String getStartDay()
    {
        return this._startDay;
    } //-- java.lang.String getStartDay() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method setCalendarYearSets the value of field
     * 'calendarYear'.
     * 
     * @param calendarYear the value of field 'calendarYear'.
     */
    public void setCalendarYear(java.lang.String calendarYear)
    {
        this._calendarYear = calendarYear;
    } //-- void setCalendarYear(java.lang.String) 

    /**
     * Method setMonthDaysSets the value of field 'monthDays'.
     * 
     * @param monthDays the value of field 'monthDays'.
     */
    public void setMonthDays(java.lang.String monthDays)
    {
        this._monthDays = monthDays;
    } //-- void setMonthDays(java.lang.String) 

    /**
     * Method setMonthNameSets the value of field 'monthName'.
     * 
     * @param monthName the value of field 'monthName'.
     */
    public void setMonthName(java.lang.String monthName)
    {
        this._monthName = monthName;
    } //-- void setMonthName(java.lang.String) 

    /**
     * Method setMonthNumberSets the value of field 'monthNumber'.
     * 
     * @param monthNumber the value of field 'monthNumber'.
     */
    public void setMonthNumber(java.lang.String monthNumber)
    {
        this._monthNumber = monthNumber;
    } //-- void setMonthNumber(java.lang.String) 

    /**
     * Method setStartDaySets the value of field 'startDay'.
     * 
     * @param startDay the value of field 'startDay'.
     */
    public void setStartDay(java.lang.String startDay)
    {
        this._startDay = startDay;
    } //-- void setStartDay(java.lang.String) 

    /**
     * Method unmarshal
     * 
     * @param reader
     */
    public static com.netwebapps.meshmcs.module.calendar.model.CalendarMonthObject unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.netwebapps.meshmcs.module.calendar.model.CalendarMonthObject) Unmarshaller.unmarshal(com.netwebapps.meshmcs.module.calendar.model.CalendarMonthObject.class, reader);
    } //-- com.netwebapps.meshmcs.module.calendar.model.CalendarMonthObject unmarshal(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
