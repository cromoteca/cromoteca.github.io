
EventCalendar is a MeshCMS module that uses an xsl style sheet to interpret xml into a
monthly calendar. It uses the following jars.

xercesImpl.jar     //Sax implementation
xmlParserAPIs.jar  //xml parser
castor-0.9.5.3.jar //xml DOM http://www.castor.org/
eventcalendar.jar  //eventCalendar core
javacsv.jar        //csv parser http://www.csvreader.com/

The module takes the following arguments.

Argument: [ path to a csv file exported from (outlook,sunbird or yahoo calendars) ] defaults
          to showing no events.

Advanced Arguments [ path to custom xsl style sheet ] defaults to the internal style sheet.

BEHAVIOR:

The calendar will load your csv file if it is newer than the the xml file stored
internally. The csv is parsed and an xml file is created and then stored for future
use. If you supplied a custom xsl file it is loaded into the transformer other wise the
internal calendar.xsl is used. The calendar is created from the xml data parsed in from
the csv file or stored from a previous visit. The calendar displays forward and back buttons
and requires that JavaScript be enabled in order to submit the form. You can put as many
events as you like into your personal calendar and export it to the eventCalendar module.
The calendar will display an event when you have click forward or back to the month
containing the event.

INSTALL:

1. unzip the contents of eventCalendar.zip.
2. Place the jars mentioned above and found in the zip content into the WEB-INF/lib
   directory of a servlet container like Tomcat.
3. Place the following files into your MeshMCS web application at the location specified.

meshcms\admin\modules\calendar\calendar.css
meshcms\admin\modules\calendar\calendar.dtd
meshcms\admin\modules\calendar\calendar.xml
meshcms\admin\modules\calendar\calendar.xsd
meshcms\admin\modules\calendar\calendar.xsl
meshcms\admin\modules\calendar\include.jsp
