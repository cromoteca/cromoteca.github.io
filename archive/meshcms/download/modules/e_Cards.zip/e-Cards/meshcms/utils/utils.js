function ValidateForm(emailID){
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Adjon meg egy e-mail c�met!")
		emailID.focus()
		return false
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false
	}
	return true
 }
