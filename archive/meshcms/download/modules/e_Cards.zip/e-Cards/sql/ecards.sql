/*Table structure for table `ecards` */

DROP TABLE IF EXISTS `ecards`;

CREATE TABLE `ecards` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `authkey` varchar(64) NOT NULL,
  `sender_name` varchar(64) NOT NULL,
  `sender_email` varchar(255) NOT NULL,
  `recipient_name` varchar(64) NOT NULL,
  `recipient_email` varchar(255) NOT NULL,
  `title` varchar(64) NOT NULL,
  `message` varchar(512) NOT NULL,
  `validto` datetime NOT NULL,
  `sendat` datetime NOT NULL,
  `imageUrl` varchar(255) NOT NULL default '',
  `sended` bit(1) NOT NULL default '\0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `Index_key` USING BTREE (`authkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

