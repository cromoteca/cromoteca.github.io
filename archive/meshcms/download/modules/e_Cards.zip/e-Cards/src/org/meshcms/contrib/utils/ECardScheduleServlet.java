package org.meshcms.contrib.utils;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.Security;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Part;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.sql.DataSource;

public class ECardScheduleServlet extends HttpServlet
{
   /**
    * 
    */
   private static final long serialVersionUID = -3031065396155362665L;
   private static final String ECARD_URL = "ecard.view";
   private static final String JDBC_URL = "ecard.jdbc";
   private static final String ENCODING = "ecard.encoding";
   private static Properties properties = null;
   public void init() throws ServletException
   {
      super.init();
      if(properties == null)
      {
         InputStream in = null;
         try
         {
            in = getClass().getClassLoader()
               .getResourceAsStream("ecard.properties");
            properties = new Properties();
            properties.load(in);

            if(properties == null)
               System.out.println("eCard properties not loaded!");

         }
         catch(Exception e)
         {
            e.printStackTrace();
         }
         finally
         {
            if(in != null)
            {
               try
               {
                  in.close();
               }
               catch(Exception e)
               {
                  throw new ServletException(e);
               }
            }
         }

      }

     

      Thread ecards = new Thread()
      {
         public void run()
         {
            System.out.println("E-cards Thread started!");
            String delete = "DELETE FROM ecards WHERE validto<=now()";
            String select = "SELECT * FROM ecards WHERE sendat<=now() && sended=0";
            String update = "UPDATE ecards SET sended=1 WHERE id=?";
            PreparedStatement ps = null;
            DataSource ds = null;
            Connection db = null;
            Statement stmt = null;
            Statement sel = null;
            ResultSet rs = null;
            try
            {
               while(true)
               {
                  try
                  {
                     Context context = new InitialContext();
                     Context envCtx = (Context)context.lookup("java:comp/env");
                     ds = (DataSource)envCtx.lookup(properties.getProperty(JDBC_URL));
                     if(ds != null)
                     {
                        db = ds.getConnection();
                     }
                     else
                     {
                        System.out.println("database NOT connected!");
                     }

                     if(db != null)
                     {
                        db.setAutoCommit(false);
                        ps = db.prepareStatement(update,ResultSet.TYPE_SCROLL_INSENSITIVE,
                                                 ResultSet.CONCUR_UPDATABLE);
                        sel = db.createStatement();
                        rs = sel.executeQuery(select);
                        sendECards(rs,ps);
                        stmt = db
                           .createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                                            ResultSet.CONCUR_UPDATABLE);
                        stmt.executeUpdate(delete);
                        db.commit();

                     }

                  }
                  catch(Exception e)
                  {
                     e.printStackTrace();
                     try
                     {
                        db.rollback();
                     }
                     catch(Exception ex)
                     {
                        ex.printStackTrace();
                     }
                  }
                  finally
                  {
                     try
                     {
                        if(rs != null)
                        {
                           rs.close();
                        }
                        if(stmt != null)
                        {
                           stmt.close();
                        }
                        if(db != null)
                        {
                           if(!db.getAutoCommit())
                              db.setAutoCommit(true);
                           db.close();
                        }
                        
                     }
                     catch(Exception e)
                     {
                        e.printStackTrace();
                     }
                  }

                  Thread.sleep(5 * 60 * 1000);

               }
            }
            catch(Exception e)
            {
               e.printStackTrace();
            }
            System.out.println("E-cards Thread terminated!");
         }
      };
    
      ecards.setDaemon(true);
      ecards.setPriority(Thread.MIN_PRIORITY);
      ecards.start();
   }
   private String loadFile(Class cl,String path) throws IOException
   {
      InputStream is = null;
      
      try
      {
         is = cl.getClassLoader().getResourceAsStream(path);
         if(is != null)
         {
            StringBuffer template = new StringBuffer();
            BufferedReader br = null;
               
            try
            {  
               br = new BufferedReader( new InputStreamReader(is));
               String line = "";
               
               while((line=br.readLine())!=null)
               {
                  template.append(line);
                  template.append("\r\n");
               }
            }
            finally
            {
               if(br != null)
                  br.close();
               if(is != null)
                  is.close();
            }
            return template.toString();
         }
         else
         {
            System.out.println("Unable to find resource:"+path);
         }
      }
      finally
      {
         if(is != null)
            is.close();
      }
      
      return null;
   
   }
   private void sendECards(ResultSet rs,PreparedStatement ps) throws MessagingException, IOException, SQLException
   {
      String css = loadFile(getClass(), "/templates/ecard.css");
      String template = loadFile(getClass(), "/templates/ecard.xhtml");
      String message = "";
      String recipientEmail = "";
      String senderEmail = "";
      String senderName = "";
      String recipientName = "";
      InternetAddress[] addresses = new InternetAddress[1];
      InternetAddress[] reply = new InternetAddress[1];
      InternetAddress senderAddress = null;
      Properties props = new Properties();
      
      props.put("mail.smtp.host", getString(props,"mail.smtp.host"));
      props.put("mail.smtp.user", getString(props,"mail.smtp.user"));
      props.put("mail.smtp.password", getString(props,"mail.smtp.password"));
      props.put("mail.smtp.auth", getString(props,"mail.smtp.auth"));
      if(getString(props,"mail.smtp.port") != null)
      {
         props.put("mail.smtp.port", getString(props,"mail.smtp.port"));
      }
      if(getString(props,"mail.smtp.socketFactory.class") != null)
      {
         props.put("mail.smtp.socketFactory.class", props
            .getProperty("mail.smtp.socketFactory.class"));
         props.put("mail.smtp.socketFactory.fallback", "false");
         props.setProperty("mail.smtp.quitwait", "false");
         props.setProperty("mail.transport.protocol", "smtp");
         props.setProperty("mail.host", getString(props,"mail.smtp.host"));
         Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
      }
      Session session = Session.getInstance(props, new javax.mail.Authenticator()
      {
         protected PasswordAuthentication getPasswordAuthentication()
         {
            return new PasswordAuthentication(properties.getProperty("mail.smtp.user"), properties.getProperty("mail.smtp.password"));
         }
      });
      MimeMessage msg = new MimeMessage(session);
      
           while(rs.next())
           {
              System.out.println("Sending eCard:"+rs.getString("authkey"));
              msg = new MimeMessage(session);
              addresses = new InternetAddress[1];
              
              message = template;
              recipientName = rs.getString("recipient_name");
              senderName = rs.getString("sender_name");
              recipientEmail = rs.getString("recipient_email");
              senderEmail = rs.getString("sender_email");
              message = message.replaceAll("@senderName@",senderName);
              message = message.replaceAll("@senderEmail@",senderEmail);
              message = message.replaceAll("@recipientName@",recipientName);
              message = message.replaceAll("@recipientEmail@",recipientEmail);
              
              message = message.replaceAll("@style@", css);
              message = message.replaceAll("@url@", getString(props,ECARD_URL));
              message = message.replaceAll("@key@",rs.getString("authkey"));
              addresses[0] = new InternetAddress(recipientEmail,recipientName);
              senderAddress = new InternetAddress(senderEmail,senderName);
              reply[0] = senderAddress;
              msg.setReplyTo(reply);
   
              msg.setFrom(senderAddress);
   
              msg.setRecipients(Message.RecipientType.TO, addresses);
              msg.setSubject(rs.getString("title"),
                             properties.getProperty(ENCODING));
              msg.setSentDate(new java.util.Date());
   
              MimeBodyPart mbpHtml = new MimeBodyPart();
   
              mbpHtml.setDisposition(Part.INLINE);
              mbpHtml.setText(message);
              mbpHtml.setContent(message, "text/html;charset="+properties.getProperty(ENCODING));
              MimeMultipart mp = new MimeMultipart();
   
              mp.addBodyPart(mbpHtml);
   
              msg.setContent(mp);
              Transport.send(msg);
              ps.setLong(1, rs.getLong("id"));
              if(ps.executeUpdate()<=0)
                 throw new SQLException("Unable to update data with id:"+rs.getLong("id"));
           }
         
           
              
              
           
           
           

           
           
   }
   private String getString(Properties bundle,String key)
   {
      String value = "";
      try
      {
         value = bundle.getProperty(key);
         if(value != null)
         {
            value = new String(value.getBytes("ISO-8859-1"),"ISO-8859-2");
         }
      }
      catch(Exception e)
      {
         e.printStackTrace();
      }
      return value;
   }
}
