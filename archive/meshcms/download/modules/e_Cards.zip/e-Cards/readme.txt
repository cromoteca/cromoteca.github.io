Readme.txt for eCards MeshCMS module
(C) Copyright Gy�rgy Vilmos Papp 2008

Prerequisites

- MySQL 5.x database connection and JDBC drivers for the TOMCAT installation
- MeshCMS 3.2+ (maybe earlier version is OK, but not tested)

INSTALL

- add the followings to your theme's main.jsp:
	<script type='text/javascript' src='/meshcms/dwr/interface/Utils.js'></script>
	<script type='text/javascript' src='/meshcms/dwr/engine.js'></script>
	<script type='text/javascript' src='/meshcms/dwr/util.js'></script>

- copy WEB-INF\lib\*.jar file into your app's WEB-INF\lib directory
- copy meshcms\admin\modules directory's content into your app's meshcms\admin\modules directory
- add WEB-INF\web.xml's content to your app's WEB-INF\web.xml
- execute the sql\ecards.sql script
- set the parameters in WEB-INF\classes\ecard.properties
- create the template (example attached) WEB-INF\classes\templates\ecard.xhtml
- place the src\web\view\viewcard.jsp in the folder and set it's url in the ecard.properties file with ecard.view setting
- on demand you can add the relevant information to your help files from meshcms\admin\help\*.html files to your app's help files


MODULE parameters
- Parameter: directory for the e-cards (files must be in jpg format with .jpg extension)

Advanced parameters for this module:
  - captions = "true" (default) | false
  - columns = n (default 3)
  - css = (name of a css class)
  - quality = "low" | "high" (the default depends on the site configuration)
  - order = "name" (default) | "date" (same as date_fwd) | "date_fwd" | "date_rev" | "random"


Credits:
Alexandre Moore [Stamp icon on the back.png for eCard module] - http://www.iconlet.com/info/81639_mail_64x64



