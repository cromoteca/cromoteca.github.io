package my.gwtsetup.server;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import dk.contix.gwt.annotations.Service;
import dk.contix.gwt.annotations.ServiceMethod;
import java.util.Date;
import my.gwtsetup.client.TimeService;

@Service(path = "/timeservice", service = "my.gwtsetup.client.TimeService")
public class TimeServiceImpl extends RemoteServiceServlet implements TimeService {

  @ServiceMethod
  public String getCurrentTime() {
    return new Date().toString();
  }
}
