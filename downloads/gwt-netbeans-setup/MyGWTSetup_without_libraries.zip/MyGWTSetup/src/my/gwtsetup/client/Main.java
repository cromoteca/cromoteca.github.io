package my.gwtsetup.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;
import dk.contix.gwt.annotations.Module;

@Module(packageName = "my.gwtsetup",
        inherits = {"com.google.gwt.user.User",
                    "com.google.gwt.user.theme.standard.Standard"})
public class Main implements EntryPoint {
  public void onModuleLoad() {
    Button button = new Button("Click me");

    VerticalPanel vPanel = new VerticalPanel();
    vPanel.setWidth("100%");
    vPanel.setHorizontalAlignment(VerticalPanel.ALIGN_CENTER);
    vPanel.add(button);

    RootPanel.get().add(vPanel);

    final DialogBox dialogBox = new DialogBox();
    dialogBox.setText("Welcome to GWT!");
    dialogBox.setAnimationEnabled(true);
    Button closeButton = new Button("close");
    VerticalPanel dialogVPanel = new VerticalPanel();
    dialogVPanel.setWidth("100%");
    dialogVPanel.setHorizontalAlignment(VerticalPanel.ALIGN_CENTER);
    dialogVPanel.add(closeButton);

    closeButton.addClickListener(new ClickListener() {
      public void onClick(Widget sender) {
        dialogBox.hide();
      }
    });

    dialogBox.setWidget(dialogVPanel);

    button.addClickListener(new ClickListener() {
      public void onClick(Widget sender) {
        TimeServiceAsync timeService = ServiceFactory.getTimeService();

        timeService.getCurrentTime(new AsyncCallback<String>() {
          public void onFailure(Throwable caught) {
            dialogBox.setText(caught.getMessage());
          }

          public void onSuccess(String result) {
            dialogBox.setText(result);
          }
        });

        dialogBox.center();
        dialogBox.show();
      }
    });
  }
}
