/*
 * Generated file. Do not edit.
*/
package my.gwtsetup.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

public interface TimeServiceAsync {

		void getCurrentTime(
		AsyncCallback<java.lang.String> callback)
;		
}
