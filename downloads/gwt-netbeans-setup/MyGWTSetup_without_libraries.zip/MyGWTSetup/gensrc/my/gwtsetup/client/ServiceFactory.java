package my.gwtsetup.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public final class ServiceFactory {
    private static final String prefix;
    static {
        String base = GWT.getModuleBaseURL();
        if (base.indexOf('/') > -1) {
	        prefix = base.substring(0, base.lastIndexOf('/') ) + "/..";
	    } else {
	        prefix = "";
	    }
    }

    private ServiceFactory() {}


    public static my.gwtsetup.client.TimeServiceAsync getTimeService() {
        my.gwtsetup.client.TimeServiceAsync service = (my.gwtsetup.client.TimeServiceAsync)GWT.create(my.gwtsetup.client.TimeService.class);
        ServiceDefTarget endpoint = (ServiceDefTarget) service;
        endpoint.setServiceEntryPoint(prefix + "/timeservice");
        return service;
    }
}
