﻿using System;
using System.Reflection;
using System.Web;
using System.Web.Configuration;
using log4net;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Context;
using NHibernate.Mapping.Attributes;
using NHibernate.Tool.hbm2ddl;
using System.IO;

/// <summary>
/// Contains all we need to use NHibernate. It might be split into more classes
/// for better clarity.
/// </summary>
public class NHibernateModule : IHttpModule {
	private static readonly ILog log = LogManager.GetLogger(typeof(NHibernateModule));

	public static readonly ISessionFactory SessionFactory;

	/// <summary>
	/// Executed at the first access to this class.
	/// </summary>
	static NHibernateModule() {
		// configure log4net
		log4net.Config.XmlConfigurator.Configure();

		// create a NHibernate configuration
		Configuration cfg = new Configuration();
		cfg.Configure();

		// load a connection string from web.config
		cfg.SetProperty("connection.connection_string",
			WebConfigurationManager.ConnectionStrings["nhwebsite"].ConnectionString);

		// validate by default (optional)
		HbmSerializer.Default.Validate = true;

		// create xml mappings from attributes in model classes
		cfg.AddInputStream(HbmSerializer.Default.Serialize(Assembly.GetExecutingAssembly()));

		// add xml mappings created manually
		cfg.AddDirectory(new DirectoryInfo(HttpContext.Current.Server.MapPath("~/App_Code")));

		// builds the session factory
		SessionFactory = cfg.BuildSessionFactory();

		// this part is optional: it is used to drop tables, recreate them and add some sample data
		SchemaExport se = new SchemaExport(cfg);
		se.Drop(false, true);
		se.Create(false, true);

		using (ISession session = OpenSession()) {
			Color color = new Color();
			color.Name = "Red";
			session.Save(color);

			color = new Color();
			color.Name = "Green";
			session.Save(color);

			color = new Color();
			color.Name = "Blue";
			session.Save(color);

			Shape shape = new Shape();
			shape.Name = "Triangle";
			session.Save(shape);

			shape = new Shape();
			shape.Name = "Square";
			session.Save(shape);

			shape = new Shape();
			shape.Name = "Circle";
			session.Save(shape);
		}

		// alternatively to drop&create, you might want to simply update your database
		// new SchemaUpdate(cfg).Execute(false, true);
	}

	/// <summary>
	/// Opens a new NHibernate Session (you'll likely want to get the Session property).
	/// </summary>
	/// <returns></returns>
	public static ISession OpenSession() {
		return SessionFactory.OpenSession();
	}

	/// <summary>
	/// The current Session (read only). It is bound to the context at the first call.
	/// </summary>
	public static ISession Session {
		get {
			if (CurrentSessionContext.HasBind(SessionFactory)) {
				return SessionFactory.GetCurrentSession();
			} else {
				ISession session = OpenSession();
				session.BeginTransaction();
				CurrentSessionContext.Bind(session);
				return session;
			}
		}
	}

	/// <summary>
	/// This HttpModule is used to define the context for NHibernate sessions.
	/// We need to handle the begin and end of requests to open/close sessions.
	/// </summary>
	/// <param name="context"></param>
	public void Init(HttpApplication context) {
		context.EndRequest += new EventHandler(CommitSession);
	}

	/// <summary>
	/// Required by the IHttpModule interface.
	/// </summary>
	public void Dispose() {
	}

	/// <summary>
	/// Closes the session and its associated transaction.
	/// </summary>
	/// <param name="sender"></param>
	/// <param name="e"></param>
	private void CommitSession(object sender, EventArgs e) {
		ISession session = CurrentSessionContext.Unbind(NHibernateModule.SessionFactory);

		if (session != null) {
			try {
				session.Transaction.Commit();
			} catch (Exception ex) {
				log.Error("Commit failed", ex);
				session.Transaction.Rollback();
				// should redirect to an error page here
			} finally {
				session.Close();
			}
		}
	}
}
