Add these files to the Bin directory:

Antlr3.Runtime.dll
Iesi.Collections.dll
Iesi.Collections.xml
LinFu.DynamicProxy.dll
log4net.dll
log4net.xml
NHibernate.ByteCode.LinFu.dll
NHibernate.ByteCode.LinFu.xml
NHibernate.dll
NHibernate.Mapping.Attributes.dll
NHibernate.xml
nhibernate-configuration.xsd
nhibernate-mapping.xsd
