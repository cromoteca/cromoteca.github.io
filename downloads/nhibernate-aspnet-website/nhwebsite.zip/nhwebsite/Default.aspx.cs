using System;
using System.Web.UI;
using NHibernate;

public partial class _Default : Page {
	protected void Page_Load(object sender, EventArgs e) {
		// get the session associated to this request
		ISession session = NHibernateModule.Session;

		// create a query to load all colors
		IQuery q = session.CreateQuery("from Color");

		// bind results to the repeater
		ColorsRepeater.DataSource = q.List();
		ColorsRepeater.DataBind();

		// create a query to load all shapes
		q = session.CreateQuery("from Shape");

		// bind results to the repeater
		ShapesRepeater.DataSource = q.List();
		ShapesRepeater.DataBind();
	}
}
